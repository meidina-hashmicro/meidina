from odoo import api, fields, models

class ResPartner(models.Model):
    _inherit = 'res.partner'

    is_customer_status_sync = fields.Boolean(string='Customer Status Sync')
    npwp = fields.Char(string="NPWP")

    @api.model
    def create(self, vals):
        if 'transaction_status' in vals:
            vals.update({'is_customer_status_sync': True})
        return super(ResPartner, self).create(vals)

    @api.multi
    def write(self, vals):
        if 'transaction_status' in vals:
            vals.update({'is_customer_status_sync': True})
        return super(ResPartner, self).write(vals)

ResPartner()