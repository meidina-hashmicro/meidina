from odoo import api, fields, models

class StockWarehouse(models.Model):
    _inherit = 'stock.warehouse'

    code = fields.Char('Short Name', required=True, size=15, help="Short name used to identify your warehouse")

StockWarehouse()

class StockInventory(models.Model):
    _inherit = 'stock.inventory'

    is_imported = fields.Boolean(string='Imported to Postgres')

StockInventory()