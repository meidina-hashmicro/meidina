import res_partner
import stock_warehouse
import sync_settings
