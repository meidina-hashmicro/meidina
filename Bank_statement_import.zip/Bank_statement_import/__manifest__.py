# -*- coding: utf-8 -*-
{
    'name': 'Bank Statement Import',
    'version': '1.0',
    'category': '',
    'author': 'Hashmicro/Janbaz Aga',
    'description': """ 	""",
    'website': 'http://www.hashmicro.com/',
    'depends': [
        'account_bank_statement_import',
    ],
    'data': [
        'wizards/account_bank_statement_import_view.xml'
    ],
    'demo': [
    ],
    'installable': True,
    'application': True,
    'auto_install': False,
}
