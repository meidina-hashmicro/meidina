# -*- coding: utf-8 -*-
{
    "name": "Payment pariod and aged invoice",
    "author": "Shivam Dudhat",
    "version": "1.0",
    'description': '''
        add aged duration in pivot view of invoice
    ''',
    'summary': 'Payment pariod and aged invoice',
    "website": "www.laxicon.in",
    "category": "Account",
    "depends": ['account'],
    "data": [
        'data/ir_crone.xml',
    ],
    "qweb": [],
    'installable': True,
    'auto_install': False,
}
