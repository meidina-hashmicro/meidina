# -*- coding: utf-8 -*-

from odoo import api, fields, models
from datetime import datetime


class AccountInvoice(models.Model):
    _inherit = "account.invoice"

    @api.multi
    @api.depends('date_invoice', 'date_due')
    def get_aged_detail(self):
        fmt = '%Y-%m-%d'
        for res in self:
            print res.date_invoice, res.date_due
            d1 = datetime.strptime(res.date_invoice, fmt)
            d2 = datetime.strptime(res.date_due, fmt)
            daysDiff = (d2-d1).days
            if daysDiff >= 0 and daysDiff <= 90:
                res.aged_status = "0-90"
            if daysDiff >= 91 and daysDiff <= 100:
                res.aged_status = "91-100"
            if daysDiff >= 101 and daysDiff <= 110:
                res.aged_status = "101-110"
            if daysDiff >= 111 and daysDiff <= 120:
                res.aged_status = "111-120"
            if daysDiff >= 121:
                res.aged_status = "> 120"

    aged_status = fields.Selection([("0-90", "0-90"), ("91-100", "91-100"), ("101-110", "101-110"), ("111-120", "111-120"), ("> 120", "> 120")], string="Aged", compute="get_aged_detail", store=True, default="0-90")

    def cron_sale_execution_dashboard_report(self):
        all_inv = self.env['account.invoice'].search([])
        fmt = '%Y-%m-%d'
        for res in all_inv:
            print res.date_invoice, res.date_due
            d1 = datetime.strptime(res.date_invoice, fmt)
            d2 = datetime.strptime(res.date_due, fmt)
            daysDiff = (d2-d1).days
            if daysDiff >= 0 and daysDiff <= 90:
                res.aged_status = "0-90"
            if daysDiff >= 91 and daysDiff <= 100:
                res.aged_status = "91-100"
            if daysDiff >= 101 and daysDiff <= 110:
                res.aged_status = "101-110"
            if daysDiff >= 111 and daysDiff <= 120:
                res.aged_status = "111-120"
            if daysDiff >= 121:
                res.aged_status = "> 120"
